package com.turbospace.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Watches the game and resets all tweaks automatically when it closes. */
class BoostService : Service() {
    @Volatile private var running = false
    private var pkg = ""

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        pkg = i?.getStringExtra("pkg") ?: return START_NOT_STICKY
        running = true

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ts", "Turbo Space", NotificationManager.IMPORTANCE_LOW))
        startForeground(
            1,
            Notification.Builder(this, "ts")
                .setContentTitle("Turbo Space active")
                .setContentText("Settings reset automatically when the game closes")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build()
        )

        Thread {
            var seen = false
            var missed = 0
            var waited = 0
            while (running) {
                Thread.sleep(4000)
                val out = Sh.run("pidof $pkg")
                if (out.startsWith("ERR")) continue
                if (out.isNotBlank()) { seen = true; missed = 0 } else if (seen) missed++ else waited++
                if ((seen && missed >= 2) || (!seen && waited >= 15)) {
                    Engine.revert(pkg)
                    running = false
                    stopSelf()
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        val p = pkg
        Thread { Engine.revert(p) }.start()
        super.onDestroy()
    }
}
