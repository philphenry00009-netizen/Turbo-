package com.turbospace.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val ready = mutableStateOf(false)
    private val listener = Shizuku.OnRequestPermissionResultListener { _, _ -> ready.value = Sh.ready() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { Shizuku.addRequestPermissionResultListener(listener) } catch (_: Throwable) {}
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    override fun onResume() { super.onResume(); ready.value = Sh.ready() }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(listener) } catch (_: Throwable) {}
        super.onDestroy()
    }

    @Composable
    fun Screen() {
        var pkg by remember { mutableStateOf("com.activision.callofduty.shooter") }
        var res by remember { mutableStateOf("1080x2280") }
        var gos by remember { mutableStateOf(true) }
        var mode by remember { mutableStateOf(true) }
        var anim by remember { mutableStateOf(true) }
        var kill by remember { mutableStateOf(true) }
        var trim by remember { mutableStateOf(true) }
        var log by remember { mutableStateOf("") }
        val isReady by ready

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Turbo Space", style = MaterialTheme.typography.headlineMedium)
            Text(
                if (isReady) "Shizuku: connected" else "Shizuku: not connected (start Shizuku, then grant access)",
                color = if (isReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
            if (!isReady) {
                Button(onClick = {
                    try {
                        if (Shizuku.pingBinder()) Shizuku.requestPermission(1)
                        else log = "Shizuku is not running. Open Shizuku and start it first."
                    } catch (e: Throwable) { log = "Shizuku error: ${e.message}" }
                }) { Text("Grant Shizuku access") }
            }

            OutlinedTextField(pkg, { pkg = it.trim() }, label = { Text("Game package") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { pkg = "com.activision.callofduty.shooter" }, label = { Text("CODM") })
                AssistChip(onClick = { pkg = "com.netease.newspike" }, label = { Text("Blood Strike") })
            }

            Text("Screen resolution (biggest GPU gain)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("" to "Native", "1080x2280" to "FHD+", "900x1900" to "900p", "720x1520" to "HD+").forEach { (v, l) ->
                    FilterChip(selected = res == v, onClick = { res = v }, label = { Text(l) })
                }
            }

            @Composable
            fun Opt(label: String, v: Boolean, set: (Boolean) -> Unit) =
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(label); Switch(v, set)
                }
            Opt("Disable Samsung GOS throttling", gos) { gos = it }
            Opt("Game Mode: performance", mode) { mode = it }
            Opt("Animations off", anim) { anim = it }
            Opt("Kill background apps", kill) { kill = it }
            Opt("Clear app caches", trim) { trim = it }

            Button(
                enabled = isReady && pkg.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    log = "Applying..."
                    Thread {
                        val r = Engine.apply(pkg, Opts(res.ifEmpty { null }, gos, mode, anim, kill, trim))
                        startForegroundService(Intent(this@MainActivity, BoostService::class.java).putExtra("pkg", pkg))
                        runOnUiThread {
                            log = r
                            val launch = packageManager.getLaunchIntentForPackage(pkg)
                            if (launch != null) startActivity(launch) else log = "$r\nGame not found: $pkg"
                        }
                    }.start()
                }
            ) { Text("Boost and launch game") }

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    Thread {
                        stopService(Intent(this@MainActivity, BoostService::class.java))
                        val r = Engine.revert(pkg)
                        runOnUiThread { log = r }
                    }.start()
                }
            ) { Text("Reset everything now") }

            if (log.isNotBlank()) Text(log, style = MaterialTheme.typography.bodySmall)
        }
    }
}
