package com.turbospace.app

data class Opts(
    val res: String?,      // e.g. "1080x2280", null = leave native
    val gos: Boolean,      // disable Samsung Game Optimizing Service
    val mode: Boolean,     // Game Mode = performance
    val anim: Boolean,     // animations off
    val kill: Boolean,     // kill background apps
    val trim: Boolean      // clear app caches
)

object Engine {
    private const val GOS = "com.samsung.android.game.gos"
    private val ANIM = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")

    fun apply(pkg: String, o: Opts): String {
        val log = mutableListOf<String>()
        fun go(label: String, cmd: String) {
            val r = Sh.run(cmd)
            log += if (r.isBlank()) "OK  $label" else "$label: $r"
        }
        if (o.kill) go("Kill background", "am kill-all")
        if (o.trim) go("Clear caches", "pm trim-caches 999G")
        if (o.res != null) go("Resolution ${o.res}", "wm size ${o.res}")
        if (o.gos) go("GOS off", "pm disable-user --user 0 $GOS")
        if (o.mode) go("Game Mode", "cmd game mode performance $pkg")
        if (o.anim) ANIM.forEach { Sh.run("settings put global $it 0") }.also { log += "OK  Animations off" }
        return log.joinToString("\n")
    }

    /** Puts everything back to normal. Safe to call any number of times. */
    fun revert(pkg: String): String {
        Sh.run("wm size reset")
        Sh.run("pm enable $GOS")
        if (pkg.isNotBlank()) Sh.run("cmd game mode standard $pkg")
        ANIM.forEach { Sh.run("settings put global $it 1") }
        return "Everything reset to normal"
    }
}
